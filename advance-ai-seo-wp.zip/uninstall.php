<?php

// if uninstall.php is not called by WordPress, die
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}
 
advance_ai_seo_meta_tags_handle_site();

if( is_multisite() ){
	
	// wordpress 4.6
	if( function_exists( 'get_sites' ) && class_exists( 'WP_Site_Query' ) ) {
		$sites = get_sites();
		foreach( $sites as $site ){
			switch_to_blog( $site->blog_id );
			advance_ai_seo_meta_tags_handle_site();
		}
	}
	else{
		
		// wordpress < 4.6
		if( function_exists( 'get_sites' ) ) {
			$sites = get_sites();
			foreach ( $sites as $site ) {
				switch_to_blog( $site['blog_id'] );
				advance_ai_seo_meta_tags_handle_site();
			}
		}
	}
}

function advance_ai_seo_meta_tags_handle_site(){
	// drop option
	delete_option( 'advance_ai_seo_meta_title' );
	delete_option( 'advance_ai_seo_meta_description' );
	delete_option( 'advance_ai_seo_meta_keywords' );
	delete_option( 'advance_ai_seo_noindex' );
	delete_option( 'advance_ai_seo_nofollow' );
	delete_option( 'advance_ai_seo_canonical' );
	delete_option( 'advance_ai_seo_twitter' );
	}
?>