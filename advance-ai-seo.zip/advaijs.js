function advanceopenCity(evt, cityName) {
  var i, advancetabcontent, advancetablinks;
  advancetabcontent = document.getElementsByClassName("advancetabcontent");
  for (i = 0; i < advancetabcontent.length; i++) {
    advancetabcontent[i].style.display = "none";
  }
  advancetablinks = document.getElementsByClassName("advancetablinks");
  for (i = 0; i < advancetablinks.length; i++) {
    advancetablinks[i].className = advancetablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}