<?php
/**
 * Plugin Name: Advance AI SEO
 * Plugin URI:        
 * Description:       SEO, optimize blog for Search Engines, Organic seo, Image seo, Video seo, web promotion, Google seo.
 * Version:           1.2.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Advance AI
 * Author URI:        
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: advance-ai-seo
 */





// Prevent direct access to the file.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



define( 'ADVANCE_AI_SEO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );


class AdvanceaiSEORun {

     function __construct() {
        // Add meta fields to the term editing pages

     add_action('admin_menu',  [$this,'advance_ai_seo_add_admin_menu']);
     add_action('admin_init', [$this,'advance_ai_seo_register_settings']);
     add_action('wp_head', [$this,'advance_ai_seo_output_meta_tags'],'');
     add_action('admin_menu', [ $this, 'advance_ai_seo_css'] );
     add_action('add_meta_boxes', [$this, 'advance_ai_seo_meta_boxes']);

    }





//=======================pages=============================================================
    public function advance_ai_seo_meta_boxes() {
        add_meta_box(
            'advance_ai_seo_meta_tags_meta_box',
            'Advance AI SEO',
            [$this, 'advance_ai_seo_render_meta_box'],
            ['post', 'page', 'elementor_library'],
            'normal',
            'high'
        );
    }

    public function advance_ai_seo_render_meta_box() {
       $wpmp= $this->advance_ai_seo_add_box();
       return $wpmp;
    }
//=======================================================================================




function advance_ai_seo_add_admin_menu() {
    add_menu_page(
        'Advance AI SEO',
        'Advance AI SEO',
        'manage_options',
        'advance_ai_seo_meta_tags',
        [$this,'advance_ai_seo_options_page'], ADVANCE_AI_SEO_PLUGIN_URL.'/ai.png');}
    
function advance_ai_seo_css() {
     
   wp_enqueue_style( 'advance-ai-seo', ( plugin_dir_url( __FILE__ ) . 'advaicss.css' ), array(), filemtime( plugin_dir_path( __FILE__ ) . 'advaicss.css' ) );
       wp_enqueue_script( 'advance-ai-seo', ( plugin_dir_url( __FILE__ ) . 'advaijs.js' ), array( 'jquery', 'postbox' ), filemtime( plugin_dir_path( __FILE__ ) . 'advaijs.js' ), true );
}

function advance_ai_seo_options_page() {
     
   
    ?>
    

        <div class="advancetab">
  <button class="advancetablinks" onclick="advanceopenCity(event, 'SEO')">Home</button>
  <button class="advancetablinks" onclick="advanceopenCity(event, 'SEOd')">SEO</button>
 
</div>
<div id="SEOd" class="advancetabcontent">
    <h3>What Is an SEO Plugin ?</h3>
  <p>Website, blog, or WooCommerce store, you’ve likely heard about SEO plugins. These powerful tools help you optimize your content and site structure to improve your rankings in search engines like Google.</p>
  <h3>SEO and WooCommerce SEO</h3>
  <p>If you're running an online store with WooCommerce, mastering SEO is essential for success. WooCommerce SEO ensures your products are visible to potential customers on search engines like Google. With the right SEO strategy, you can increase traffic, improve rankings, and drive more sales.
<br/>
In this comprehensive guide, we’ll cover everything you need to know about SEO, with a special focus on WooCommerce SEO to help your online store rank higher and perform better.</p>
<h3>What Is SEO ?</h3>
  <p>SEO, or Search Engine Optimization, is the process of improving your website’s visibility on search engines. Good SEO helps your pages appear higher in search results, increasing organic traffic.
<br/>
For WooCommerce users, WooCommerce SEO refers to optimizing your online store — including product pages, categories, images, and more — for search engines.</p>
<h3>Why Is SEO Important for WooCommerce ?</h3>
  <p>Without SEO, your WooCommerce store could get buried deep in search results. Here’s why WooCommerce SEO is crucial:
<br/>
SEO drives free, organic traffic.
<br/>
WooCommerce SEO increases product visibility.
<br/>
SEO improves click-through rates and conversions.
<br/>
WooCommerce SEO boosts your brand’s credibility and trust.
<br/>
An optimized store using smart SEO strategies will outperform competitors relying solely on paid ads.</p>
<h3>WooCommerce SEO Best Practices</h3>
  <p>Let’s dive into key WooCommerce SEO strategies to optimize your online store effectively:</p>
<h3>1. Optimize Product Titles and Descriptions</h3>
  <p>Use relevant SEO keywords naturally in your product titles and descriptions. Ensure every product page is unique and keyword-rich.</p>
<h3>2. Use SEO-Friendly URLs</h3>
  <p>Keep URLs short, descriptive, and include your main SEO keywords.</p>
<h3>3. Improve Site Speed and Mobile Experience</h3>
  <p>Google prioritizes mobile-friendly, fast-loading sites. Good SEO depends on performance. Use lightweight themes and optimize images for faster loading.</p>
<h3>4. Install an SEO Plugin</h3>
  <p>Use an SEO plugin like Yoast SEO or Rank Math SEO for WooCommerce. These tools guide you through on-page SEO optimization and help manage your WooCommerce SEO effectively.</p>
<h3>5. Use Structured Data and Schema Markup</h3>
  <p>Implement schema for WooCommerce products. This enhances search listings with reviews, prices, and availability, boosting SEO visibility.</p>
<h3>6. Optimize Product Images</h3>
  <p>Use descriptive alt tags with SEO keywords. Compress images for speed. Image SEO can drive traffic from Google Images.</p>
<h3>7. Create SEO-Friendly Categories and Tags</h3>
  <p>Group your products logically using SEO-optimized categories and tags. This helps both users and search engines navigate your site.</p>
<h3>Technical SEO for WooCommerce</h3>
  <p>In addition to content-focused WooCommerce SEO, you must handle technical SEO:
<br/>
Use XML sitemaps for easy indexing.
<br/>
Set canonical URLs to avoid duplicate content.
<br/>
Use 301 redirects for old or deleted pages.
<br/>
Ensure your site is HTTPS-secured — a SEO ranking factor.
<br/>
Use robots.txt to control what search engines crawl.
</p>
<h3>Local SEO for WooCommerce Stores</h3>
  <p>If your WooCommerce store serves a specific region, local SEO is key. Optimize your Google Business Profile, use local keywords, and get local backlinks. Local WooCommerce SEO helps attract nearby customers.
</p>
<h3>Content Marketing and SEO for WooCommerce</h3>
  <p>Create valuable blog content targeting SEO keywords relevant to your products. This improves authority and keeps your site fresh — both key to long-term SEO success.
<br/>
Ideas for WooCommerce content include:
<br/>
Product comparisons
<br/>
How-to guides
<br/>
Buyer’s guides
<br/>
Customer stories
<br/>
Industry news
<br/>
All of these improve SEO and provide extra value to your audience.</p>
<h3>Link Building for WooCommerce SEO</h3>
  <p>Backlinks are still one of the strongest SEO signals. For effective WooCommerce SEO:
<br/>
Reach out to bloggers for product reviews.
<br/>
Guest post on niche websites.
<br/>
Get listed on e-commerce directories.
<br/>
Partner with influencers for backlinks and visibility.
</p>
<h3>Monitor and Improve Your SEO Performance</h3>
  <p>Use tools like:
<br/>
Google Search Console – Track your SEO performance.
<br/>
Google Analytics – See how SEO traffic converts.
<br/>
SEMrush, Ahrefs, or Ubersuggest – Analyze your WooCommerce SEO and competition.
<br/>
Regularly audit your store to identify and fix SEO issues.</p>
<h3>Final Thoughts: Maximize Your WooCommerce SEO Potential</h3>
  <p>SEO is not optional for WooCommerce — it’s critical. With the right WooCommerce SEO tactics, your store can rise above the competition, attract more organic traffic, and drive more conversions.
<br/>
Investing in SEO for your WooCommerce store ensures long-term growth, visibility, and sales success. Start implementing strong SEO strategies today and watch your WooCommerce store thrive.</p>

</div>




  
        
       
    <?php ///*  ?>
       <div id="SEO" class="advancetabcontent">
       
       <?php //echo get_option('page_on_front');; ?> 
        
        
            <h1>Advance AI SEO - Home Page Meta Tags</h1>
            
            <form action="options.php" method="post">
            <?php
            settings_fields('advance_ai_seo_options_group');
            do_settings_sections('advance_ai_seo_meta_tags');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Title', 'advance-ai-seo'); ?></th>
                    <td><input type="text" name="advance_ai_seo_meta_title" value="<?php echo esc_attr(get_option('advance_ai_seo_meta_title')); ?>" class="regular-text" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Description', 'advance-ai-seo'); ?></th>
                    <td><textarea name="advance_ai_seo_meta_description" rows="5" cols="45" class="large-text1"><?php echo esc_textarea(get_option('advance_ai_seo_meta_description')); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Meta Keywords', 'advance-ai-seo'); ?></th>
                    <td>Use comma(,) to separate the keywords.<br/><textarea name="advance_ai_seo_meta_keywords" rows="2" cols="45" class="large-text1"><?php echo esc_textarea(get_option('advance_ai_seo_meta_keywords')); ?></textarea></td>
                </tr>                
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Noindex', 'advance-ai-seo'); ?></th>
                    <td>
                        <label><input type="radio" name="advance_ai_seo_noindex" value="1" <?php checked(1, get_option('advance_ai_seo_noindex')); ?> /> Yes</label>
                        <label><input type="radio" name="advance_ai_seo_noindex" value="0" <?php checked(0, get_option('advance_ai_seo_noindex')); ?> /> No</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Nofollow', 'advance-ai-seo'); ?></th>
                    <td>
                        <label><input type="radio" name="advance_ai_seo_nofollow" value="1" <?php checked(1, get_option('advance_ai_seo_nofollow')); ?> /> Yes</label>
                        <label><input type="radio" name="advance_ai_seo_nofollow" value="0" <?php checked(0, get_option('advance_ai_seo_nofollow')); ?> /> No</label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Canonical URL', 'advance-ai-seo'); ?></th>
                    <td><input type="text" name="advance_ai_seo_canonical" value="<?php echo esc_attr(get_option('advance_ai_seo_canonical')); ?>" class="regular-text" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Twitter image URL', 'advance-ai-seo'); ?></th>
                    <td><input type="text" name="advance_ai_seo_twitter" value="<?php echo esc_attr(get_option('advance_ai_seo_twitter')); ?>" class="regular-text" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <br/><br/><br/><br/>
        <a href='https://advanceao009.github.io/advanceai/' target='_blank'>
        <p class="advanceimg">&nbsp;</p>
        </a>
        <br/><br/><br/><br/>
    </div>
    
<?php //*/ ?>








    
    
   
    
    
           
    

    
    <?php
    
    
   
}




function advance_ai_seo_register_settings() {
    

    
     $args = array(
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => '',

        
    );





    register_setting('advance_ai_seo_options_group', 'advance_ai_seo_meta_title', $args);
    register_setting('advance_ai_seo_options_group', 'advance_ai_seo_meta_description', $args);
    register_setting('advance_ai_seo_options_group', 'advance_ai_seo_meta_keywords', $args);
    // For noindex and nofollow, using 'intval' to sanitize as these are expected to be integers (1 or 0)
    $args_noindex = array(
        'type' => 'integer',
        'sanitize_callback' => 'intval',
        'default' => 0,
    );
    register_setting('advance_ai_seo_options_group', 'advance_ai_seo_noindex', $args_noindex);
    register_setting('advance_ai_seo_options_group', 'advance_ai_seo_nofollow', $args_noindex);

    // Canonical URL should be sanitized using 'esc_url_raw'
    $args_canonical = array(
        'type' => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default' => '',
    );
    register_setting('advance_ai_seo_options_group', 'advance_ai_seo_canonical', $args_canonical);
    register_setting('advance_ai_seo_options_group', 'advance_ai_seo_twitter', $args_twitter);
    
    
    

    
    
    
    
    
    
}



public function advance_ai_seo_add_box() { ?>

    <div class="advanceaide">
    <tr class="form-field">
        <th><label for="meta_title"><h1>Advance AI SEO</h1></label></th>
    </tr> 
    <tr class="form-field">
        <th><label for="meta_title"><h1>We are the best.</h1></label></th>
    </tr>
    </div>
<?php
}




function advance_ai_seo_output_meta_tags() {
    if (is_front_page()) { ?>
        <!-- Advance AI SEO Meta Description - -->
        <?php     if (!empty(get_option('advance_ai_seo_meta_title'))) { ?>
<title><?php echo esc_attr(get_option('advance_ai_seo_meta_title')); ?></title>
        <?php  }   if (!empty(get_option('advance_ai_seo_meta_description'))) { ?>
<meta name="description" content="<?php echo esc_attr(get_option('advance_ai_seo_meta_description')); ?>" />
        <?php } ?>
<meta property="og:type" content=""/>
        <meta property="og:title" content="<?php echo esc_attr(get_option('advance_ai_seo_meta_title')); ?>"/>
        <meta property="og:description" content="<?php echo esc_attr(get_option('advance_ai_seo_meta_description')); ?>"/>
        <?php if (!empty(get_option('advance_ai_seo_meta_keywords'))) { ?>
<meta name="keywords" content="<?php echo esc_attr(get_option('advance_ai_seo_meta_keywords')); ?>" />
<?php } ?>
        <meta property="og:url" content="<?php echo esc_url(get_option('siteurl')); ?>"/>
        <meta property="og:site_name" content="<?php echo esc_attr(get_option('blogname')); ?>"/>
        <meta name="twitter:title" content="<?php echo esc_attr(get_option('advance_ai_seo_meta_title')); ?>"/>
        <meta name="twitter:description" content="<?php echo esc_attr(get_option('advance_ai_seo_meta_description')); ?>"/>
        <meta name="twitter:image" content="<?php echo esc_url(get_option('advance_ai_seo_twitter')); ?>"/>
        <meta name="twitter:card" content="summary_large_image"/>
        <meta name="robots" content="" class="" />
<?php if(!empty(get_option('advance_ai_seo_canonical'))) { ?>
        <link rel="canonical" href="<?php echo esc_url(get_option('advance_ai_seo_canonical')); ?>" />
<?php }if (get_option('advance_ai_seo_noindex')) : ?>
        <meta name="robots" content="noindex" />
        <?php endif; ?><?php if (get_option('advance_ai_seo_nofollow')) : ?>
<meta name="robots" content="nofollow" />
<?php endif; ?>
        <!-- END Advance AI SEO Meta Description - -->
        <?php
    }
}


 
 
 
   
}


    
    new AdvanceaiSEORun();
    

    
    
    
    
    
    
    









